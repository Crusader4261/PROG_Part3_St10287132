﻿
using System;
using System.Collections.Generic;
using System.Linq;

namespace recipeApp
{
    public class recipe
    {
        SortedList<int, string> nameOfIngredient;
        SortedList<int, double> quantity;
        SortedList<int, string> unitOfMeasurement;
        SortedList<int, string> steps;
        double[] initialQuantity;

        public string name { get; set; }
        public List<Ingredient> Ingredients { get; set; }
        public static List<recipe> recs = new List<recipe>();

        public delegate void CaloriesExceededHandler(string message);

        public event CaloriesExceededHandler OnCaloriesExceeded;

        public recipe()
        {
            nameOfIngredient = new SortedList<int, string>();
            quantity = new SortedList<int, double>();
            unitOfMeasurement = new SortedList<int, string>();
            steps = new SortedList<int, string>();
            Ingredients = new List<Ingredient>();
        }

        public void inputRecipeDetails()
        {
            Console.ForegroundColor = ConsoleColor.Cyan;
            Console.WriteLine("Enter the recipe name:");
            name = Console.ReadLine();
            if (string.IsNullOrWhiteSpace(name))
            {
                Console.WriteLine("Recipe name cannot be empty.");
                return;
            }

            Console.ForegroundColor = ConsoleColor.Cyan;
            Console.WriteLine("How many ingredients are you going to use?");
            if (!int.TryParse(Console.ReadLine(), out int numOfIngredients) || numOfIngredients <= 0)
            {
                Console.WriteLine("Please enter a valid number of ingredients.");
                return;
            }

            nameOfIngredient.Clear();
            quantity.Clear();
            unitOfMeasurement.Clear();
            steps.Clear();
            Ingredients.Clear();

            for (int i = 0; i < numOfIngredients; i++)
            {
                Ingredient ingredient = new Ingredient();

                Console.WriteLine("Name of ingredient:");
                string ingredientName = Console.ReadLine();
                if (string.IsNullOrWhiteSpace(ingredientName))
                {
                    Console.WriteLine("Ingredient name cannot be empty.");
                    return;
                }
                nameOfIngredient.Add(i, ingredientName);
                ingredient.name = ingredientName;

                Console.WriteLine("Quantity of the ingredient:");
                if (!double.TryParse(Console.ReadLine(), out double ingredientQuantity) || ingredientQuantity <= 0)
                {
                    Console.WriteLine("Please enter a valid quantity.");
                    return;
                }
                quantity.Add(i, ingredientQuantity);

                Console.WriteLine("Unit of Measurement:");
                string ingredientUnit = Console.ReadLine();
                if (string.IsNullOrWhiteSpace(ingredientUnit))
                {
                    Console.WriteLine("Unit of Measurement cannot be empty.");
                    return;
                }
                unitOfMeasurement.Add(i, ingredientUnit);

                Console.WriteLine("Calories of ingredient:");
                if (!int.TryParse(Console.ReadLine(), out int ingredientCalories) || ingredientCalories <= 0)
                {
                    Console.WriteLine("Please enter a valid number of calories.");
                    return;
                }
                ingredient.calories = ingredientCalories;

                Console.WriteLine("Food group of ingredient:");
                string ingredientFoodGroup = Console.ReadLine();
                if (string.IsNullOrWhiteSpace(ingredientFoodGroup))
                {
                    Console.WriteLine("Food group cannot be empty.");
                    return;
                }
                ingredient.foodGroup = ingredientFoodGroup;

                Ingredients.Add(ingredient);
            }

            Console.ForegroundColor = ConsoleColor.Cyan;
            Console.WriteLine("Number steps are there going to be in your recipe?");
            if (!int.TryParse(Console.ReadLine(), out int numOfSteps) || numOfSteps <= 0)
            {
                Console.WriteLine("Please enter a valid number of steps.");
                return;
            }

            for (int i = 0; i < numOfSteps; i++)
            {
                Console.WriteLine($"Write a description of steps (Step number_{i + 1}):");
                string stepDescription = Console.ReadLine();
                if (string.IsNullOrWhiteSpace(stepDescription))
                {
                    Console.WriteLine("Step description cannot be empty.");
                    return;
                }
                steps.Add(i, stepDescription);
            }

            initialQuantity = new double[numOfIngredients];
            for (int i = 0; i < numOfIngredients; i++)
            {
                initialQuantity[i] = quantity[i];
            }

            recs.Add(this);
            Console.ForegroundColor = ConsoleColor.Cyan;
            Console.WriteLine("Finished");
        }

        public void AddIngredients(List<Ingredient> ingredients)
        {
            foreach (var ingredient in ingredients)
            {
                Ingredients.Add(ingredient);
            }
        }

        public void recipeOutput()
        {
            Console.ForegroundColor = ConsoleColor.Cyan;

            Console.WriteLine("Recipe Ingredients:");

            foreach (var item in nameOfIngredient)
            {
                Console.WriteLine($"{quantity[item.Key]} {unitOfMeasurement[item.Key]} of {item.Value}");
            }

            Console.WriteLine("Ingredients Details:");

            foreach (Ingredient ingredient in Ingredients)
            {
                Console.WriteLine($"- {ingredient.name} ({ingredient.calories} cal, {ingredient.foodGroup})");
            }

            Console.WriteLine("Recipe Steps:");

            foreach (var item in steps)
            {
                Console.WriteLine($"{item.Key + 1}. {item.Value}");
            }

            int totalCalories = Ingredients.Sum(i => i.calories);
            Console.WriteLine("Total Calories: " + totalCalories);

            if (totalCalories > 300)
            {
                ConsoleColor color = ConsoleColor.Red;
                OnCaloriesExceeded?.Invoke($"This recipe exceeds 300 calories. Total: {totalCalories}");
                Console.ForegroundColor = ConsoleColor.Red;
            }
        }

        public void scaling(double factor)
        {
            for (int i = 0; i < quantity.Count; i++)
            {
                quantity[i] = initialQuantity[i] * factor;
            }
        }

        public void resetQuantities()
        {
            for (int i = 0; i < quantity.Count; i++)
            {
                quantity[i] = initialQuantity[i];
            }
        }

        public void clearData()
        {
            nameOfIngredient.Clear();
            quantity.Clear();
            unitOfMeasurement.Clear();
            steps.Clear();
            Ingredients.Clear();
        }

        public void removeRecipe()
        {
            recs.Remove(this);
        }

        public class Ingredient
        {
            public string name { get; set; }
            public int calories { get; set; }
            public string foodGroup { get; set; }
        }

        public static void ViewRecipeList()
        {
            Console.ForegroundColor = ConsoleColor.Cyan;
            Console.WriteLine("\nRecipe List:");
            Console.WriteLine(" ");
            if (recs.Count == 0)
            {
                Console.WriteLine("No recipes found.");
                return;
            }
            List<recipe> sortedRecipes = recs.OrderBy(r => r.name).ToList();
            foreach (recipe rec in sortedRecipes)
            {
                Console.WriteLine("- " + rec.name);
            }

            Console.WriteLine("Enter the name of the recipe to display its details:");
            string selectedRecipeName = Console.ReadLine();
            recipe selectedRecipe = recs.FirstOrDefault(r => r.name == selectedRecipeName);
            if (selectedRecipe != null)
            {
                DisplayRecipe(selectedRecipe);
            }
            else
            {
                Console.WriteLine("Recipe not found");
            }
        }

        public static void DisplayRecipe(recipe rec)
        {
            Console.ForegroundColor = ConsoleColor.Cyan;
            Console.WriteLine("\nRecipe: " + rec.name);
            Console.WriteLine("*******************");
            Console.WriteLine("Ingredients:");
            Console.WriteLine("*******************");
            foreach (Ingredient ingredient in rec.Ingredients)
            {
                Console.WriteLine("- " + ingredient.name + " (" + ingredient.calories + " cal, " + ingredient.foodGroup + ")");
            }
            int totalCalories = rec.Ingredients.Sum(i => i.calories);
            Console.WriteLine("Total Calories: " + totalCalories);

            if (totalCalories > 300)
            {
                Console.ForegroundColor = ConsoleColor.Red;
                Console.WriteLine("This recipe exceeds 300 calories");
                Console.ForegroundColor = ConsoleColor.Cyan;
            }
        }

        public int totalCalories()
        {
            return Ingredients.Sum(i => i.calories);
        }

        public static void ClearAllRecipes()
        {
            recs.Clear();
            Console.WriteLine("All recipes have been deleted.");
        }

        class Execute
        {
            public static void Main(string[] args)
            {
                while (true)
                {
                    Console.ForegroundColor = ConsoleColor.Cyan;
                    Console.WriteLine("******************************************************");
                    Console.WriteLine("Super secret Recipe App");
                    Console.WriteLine("  ");
                    Console.WriteLine("1. add a new recipe ");
                    Console.WriteLine("2. output the full recipe");
                    Console.WriteLine("3. scale the recipe");
                    Console.WriteLine("4. Revert to original quantity");
                    Console.WriteLine("5. remove a Recipe completely");
                    Console.WriteLine("6. view the recipe list");
                    Console.WriteLine("7. delete all recipes");
                    Console.WriteLine("8. exit");
                    Console.WriteLine("******************************************************");

                    string option = Console.ReadLine();
                    switch (option)
                    {
                        case "1":
                            recipe newRecipe = new recipe();
                            newRecipe.OnCaloriesExceeded += (message) => Console.WriteLine(message);
                            newRecipe.inputRecipeDetails();
                            break;

                        case "2":
                            Console.WriteLine("Enter the name of the recipe to output:");
                            string recipeName = Console.ReadLine();
                            recipe selectedRecipe = recipe.recs.FirstOrDefault(r => r.name == recipeName);
                            if (selectedRecipe != null)
                            {
                                selectedRecipe.OnCaloriesExceeded += (message) => Console.WriteLine(message);
                                selectedRecipe.recipeOutput();
                            }
                            else
                            {
                                Console.WriteLine("Recipe not found");
                            }
                            break;

                        case "3":
                            Console.ForegroundColor = ConsoleColor.Cyan;
                            Console.WriteLine("Enter a scaling factor: 0.5, 2, or 3");
                            if (!double.TryParse(Console.ReadLine(), out double factor) || (factor != 0.5 && factor != 2 && factor != 3))
                            {
                                Console.WriteLine("Please enter a valid scaling factor.");
                                break;
                            }
                            Console.WriteLine("Enter the name of the recipe to scale:");
                            string recipeToScale = Console.ReadLine();
                            recipe recipeToScaleInstance = recipe.recs.FirstOrDefault(r => r.name == recipeToScale);
                            if (recipeToScaleInstance != null)
                            {
                                recipeToScaleInstance.scaling(factor);
                                Console.WriteLine("Recipe scaled successfully.");
                            }
                            else
                            {
                                Console.WriteLine("Recipe not found");
                            }
                            break;

                        case "4":
                            Console.WriteLine("Enter the name of the recipe to reset quantities:");
                            string recipeToReset = Console.ReadLine();
                            recipe recipeToResetInstance = recipe.recs.FirstOrDefault(r => r.name == recipeToReset);
                            if (recipeToResetInstance != null)
                            {
                                recipeToResetInstance.resetQuantities();
                                Console.WriteLine("Quantities reset successfully.");
                            }
                            else
                            {
                                Console.WriteLine("Recipe not found");
                            }
                            break;

                        case "5":
                            Console.WriteLine("Enter the name of the recipe to remove:");
                            string recipeToRemove = Console.ReadLine();
                            recipe recipeToRemoveInstance = recipe.recs.FirstOrDefault(r => r.name == recipeToRemove);
                            if (recipeToRemoveInstance != null)
                            {
                                recipeToRemoveInstance.removeRecipe();
                                Console.WriteLine("Recipe removed successfully.");
                            }
                            else
                            {
                                Console.WriteLine("Recipe not found");
                            }
                            break;

                        case "6":
                            recipe.ViewRecipeList();
                            break;

                        case "7":
                            recipe.ClearAllRecipes();
                            break;

                        case "8":
                            Console.WriteLine("Closing Application...");
                            return;

                        default:
                            Console.WriteLine("Invalid option. Enter the correct option.");
                            break;
                    }
                }
            }
        }

        public class RecipeCalculator
        {
            private recipe _recipe;

            public RecipeCalculator()
            {
                _recipe = new recipe();
            }

            public void AddIngredients(List<recipe.Ingredient> ingredients)
            {
                foreach (var ingredient in ingredients)
                {
                    _recipe.Ingredients.Add(ingredient);
                }
            }

            public bool IsTotalCaloriesWithinLimit(double maxCalories)
            {
                return _recipe.totalCalories() <= maxCalories;
            }

            // Helper method to calculate total calories
            private double TotalCalories(recipe recipe)
            {
                return recipe.Ingredients.Sum(i => i.calories);
            }
        }
    }
}
