﻿using System.Windows;

namespace RecipeFilterApp
{
    public partial class RecipeDetailsWindow : Window
    {
        public RecipeDetailsWindow(Recipe recipe)
        {
            InitializeComponent();
            DisplayRecipeDetails(recipe);
        }

        private void DisplayRecipeDetails(Recipe recipe)
        {
            RecipeNameTextBox.Text = recipe.Name;
            FoodGroupTextBox.Text = recipe.FoodGroup;
            CaloriesTextBox.Text = recipe.Calories.ToString();

            string ingredientsText = "";
            foreach (var ingredient in recipe.Ingredients)
            {
                ingredientsText += $"- {ingredient}\n";
            }
            IngredientsTextBox.Text = ingredientsText;
        }
    }
}
