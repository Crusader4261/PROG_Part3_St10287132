﻿using System.Collections.Generic;
using System.Linq;
using System.Windows;
using System.Windows.Controls;

namespace RecipeFilterApp
{
    public partial class RecipeInputWindow : Window
    {
        public Recipe NewRecipe { get; private set; }

        public RecipeInputWindow()
        {
            InitializeComponent();
        }

        private void AddRecipeButton_Click(object sender, RoutedEventArgs e)
        {
            string name = RecipeNameTextBox.Text;
            List<string> ingredients = IngredientsTextBox.Text.Split(',').Select(i => i.Trim()).ToList();
            string foodGroup = (FoodGroupComboBox.SelectedItem as ComboBoxItem)?.Content.ToString();
            int calories = (int)CaloriesSlider.Value;

            if (!string.IsNullOrEmpty(name) && ingredients.Count > 0 && !string.IsNullOrEmpty(foodGroup))
            {
                NewRecipe = new Recipe
                {
                    Name = name,
                    Ingredients = ingredients,
                    FoodGroup = foodGroup,
                    Calories = calories
                };

                DialogResult = true;
                Close();
            }
            else
            {
                MessageBox.Show("Please fill in all fields to add a new recipe.");
            }
        }
    }
}
