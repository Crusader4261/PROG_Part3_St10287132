﻿using System.Windows;
using System.Windows.Controls;

namespace RecipeFilterApp
{
    public partial class MainWindow : Window
    {
        private List<Recipe> _recipes;

        public MainWindow()
        {
            InitializeComponent();
            LoadRecipes();
        }

        private void LoadRecipes()
        {
            _recipes = new List<Recipe>
            {
                new Recipe { Name = "Salad", Ingredients = new List<string> { "Lettuce", "Tomato" }, FoodGroup = "Vegetables", Calories = 150 },
                new Recipe { Name = "Chicken Sandwich", Ingredients = new List<string> { "Chicken", "Bread" }, FoodGroup = "Meat", Calories = 400 },
            };
            UpdateRecipeList();
        }

        private void FilterRecipesButton_Click(object sender, RoutedEventArgs e)
        {
            string ingredient = IngredientTextBox.Text.ToLower();
            string foodGroup = (FoodGroupComboBox.SelectedItem as ComboBoxItem)?.Content.ToString()?.ToLower();
            int maxCalories = (int)CaloriesSlider.Value;

            var filteredRecipes = _recipes.Where(r =>
                (string.IsNullOrEmpty(ingredient) || r.Ingredients.Any(i => i.ToLower().Contains(ingredient))) &&
                (string.IsNullOrEmpty(foodGroup) || r.FoodGroup.ToLower() == foodGroup) &&
                r.Calories <= maxCalories
            ).ToList();

            RecipesListBox.ItemsSource = filteredRecipes;
        }

        private void OpenRecipeInputWindow_Click(object sender, RoutedEventArgs e)
        {
            RecipeInputWindow recipeInputWindow = new RecipeInputWindow();
            if (recipeInputWindow.ShowDialog() == true)
            {
                Recipe newRecipe = recipeInputWindow.NewRecipe;
                _recipes.Add(newRecipe);
                UpdateRecipeList();
            }
        }

      
        private void UpdateRecipeList()
        {
            RecipesListBox.ItemsSource = null;
            RecipesListBox.ItemsSource = _recipes;
        }

        private void ShowRecipeDetails_Click(object sender, RoutedEventArgs e)
        {
            Recipe selectedRecipe = RecipesListBox.SelectedItem as Recipe;
            if (selectedRecipe != null)
            {
                RecipeDetailsWindow recipeDetailsWindow = new RecipeDetailsWindow(selectedRecipe);
                recipeDetailsWindow.Owner = this;
                recipeDetailsWindow.ShowDialog();
            }
            else
            {
                MessageBox.Show("Please select a recipe to view details.");
            }
        }
     

            private void DeleteAllRecipes_Click(object sender, RoutedEventArgs e)
        {
            if (MessageBox.Show("Are you sure you want to delete all recipes?", "Confirm Delete", MessageBoxButton.YesNo, MessageBoxImage.Question) == MessageBoxResult.Yes)
            {
                _recipes.Clear();
                UpdateRecipeList();
            }
        }

       
    }
  

    public class Recipe
    {
        public string Name { get; set; }
        public List<string> Ingredients { get; set; }
        public string FoodGroup { get; set; }
        public int Calories { get; set; }
    }
}
